/// <reference path="globals/cheerio/index.d.ts" />
/// <reference path="globals/fs-extra/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/q/index.d.ts" />
/// <reference path="globals/string/index.d.ts" />
/// <reference path="globals/xml2js/index.d.ts" />
