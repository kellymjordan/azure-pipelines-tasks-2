import fs = require('fs');
import assert = require('assert');
import path = require('path');

describe('AntV1 Suite', function () {
    before(() => {
    });

    after(() => {
    });

    it('Does a basic hello world test', function(done: MochaDone) {
        // TODO - add real tests
        done();
    });
});
