
export class TestString {
    public static readonly getResourceGroupNameFromUrlKeyword: string = "getResourceGroupNameFromUrl extracted the ResourceGroup successfully";
    public static readonly getListOfTagValuesForImageNamesKeyword: string = "getListOfTagValuesForImageNames constructed the correct task run tag name and tag value";
    public static readonly getImageNamesForGitKeyword: string = "getImageNames for context type git should construct the correct task image names";
    public static readonly getImageNamesForFileKeyword: string = "getImageNames for context type file should construct the correct task image names";
    public static readonly createBuildCommandKeyWord: string = "createBuildCommand should construct the correct task build command string";
}